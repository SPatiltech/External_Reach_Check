#!/bin/bash
# =============================================================================
# check_exposure.sh — Internet Exposure Checker (Linux/macOS)
# =============================================================================
# Usage:
#   On the target machine:   ./check_exposure.sh
#   On a proxy/jump host:    ./check_exposure.sh --target <IP_OR_HOSTNAME>
#
# Requirements: curl, nc (netcat), bash 4+
# =============================================================================

set -euo pipefail

# ---------- Config ------------------------------------------------------------
PORTS_TO_CHECK=(22 80 443 3389 8080 8443)   # Ports to probe
EXTERNAL_IP_SERVICE="https://api.ipify.org"
SHODAN_HOST_API="https://internetdb.shodan.io"
TARGET=""
MODE="local"

# ---------- Colors ------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ---------- Parse args --------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case $1 in
    --target|-t) TARGET="$2"; MODE="proxy"; shift 2 ;;
    --ports|-p)  IFS=',' read -ra PORTS_TO_CHECK <<< "$2"; shift 2 ;;
    --help|-h)
      echo "Usage: $0 [--target <IP>] [--ports 22,80,443]"
      exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ---------- Banner ------------------------------------------------------------
echo ""
echo -e "${BOLD}${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${CYAN}║     Internet Exposure Checker v1.0       ║${NC}"
echo -e "${BOLD}${CYAN}║     Linux / macOS Edition                ║${NC}"
echo -e "${BOLD}${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Mode     : ${BOLD}${MODE}${NC}"
echo -e "  Run time : $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo ""

# ---------- Step 1: Resolve target IP ----------------------------------------
echo -e "${BOLD}[1/4] Resolving target...${NC}"

if [[ "$MODE" == "local" ]]; then
  # Get the machine's own public IP
  PUBLIC_IP=$(curl -s --max-time 5 "$EXTERNAL_IP_SERVICE" 2>/dev/null || echo "UNREACHABLE")
  if [[ "$PUBLIC_IP" == "UNREACHABLE" ]]; then
    echo -e "  ${RED}✗ Could not reach external IP service. Check internet connectivity.${NC}"
    exit 1
  fi
  TARGET="$PUBLIC_IP"
  echo -e "  Local machine's public IP : ${BOLD}$PUBLIC_IP${NC}"
else
  # Try to resolve hostname to IP if needed
  if [[ "$TARGET" =~ ^[a-zA-Z] ]]; then
    RESOLVED=$(getent hosts "$TARGET" 2>/dev/null | awk '{print $1}' | head -1 || echo "")
    if [[ -z "$RESOLVED" ]]; then
      echo -e "  ${RED}✗ Could not resolve hostname: $TARGET${NC}"
      exit 1
    fi
    echo -e "  Target host : ${BOLD}$TARGET${NC} → ${BOLD}$RESOLVED${NC}"
    TARGET="$RESOLVED"
  else
    echo -e "  Target IP   : ${BOLD}$TARGET${NC}"
  fi
fi

echo ""

# ---------- Step 2: Port scan (outbound probe) --------------------------------
echo -e "${BOLD}[2/4] Checking port reachability from this host...${NC}"
echo -e "  (Tests if ports respond — does NOT confirm internet-wide exposure)"
echo ""

OPEN_PORTS=()
CLOSED_PORTS=()

for PORT in "${PORTS_TO_CHECK[@]}"; do
  # Use nc with a 2-second timeout
  if nc -z -w 2 "$TARGET" "$PORT" 2>/dev/null; then
    echo -e "  Port ${BOLD}$PORT${NC}  →  ${GREEN}OPEN / REACHABLE${NC}"
    OPEN_PORTS+=("$PORT")
  else
    echo -e "  Port ${BOLD}$PORT${NC}  →  ${RED}CLOSED / FILTERED${NC}"
    CLOSED_PORTS+=("$PORT")
  fi
done

echo ""

# ---------- Step 3: Shodan InternetDB lookup ----------------------------------
echo -e "${BOLD}[3/4] Querying Shodan InternetDB (no API key required)...${NC}"
echo -e "  Checking known internet-facing exposure for: ${BOLD}$TARGET${NC}"
echo ""

SHODAN_RESULT=$(curl -s --max-time 8 "${SHODAN_HOST_API}/${TARGET}" 2>/dev/null || echo "{}")

# Parse JSON fields (no jq dependency — pure bash)
SHODAN_PORTS=$(echo "$SHODAN_RESULT" | grep -oP '"ports":\[.*?\]' | grep -oP '\d+' || echo "")
SHODAN_VULNS=$(echo "$SHODAN_RESULT" | grep -oP '"vulns":\[.*?\]' | grep -oP '"[^"]*"' | tr -d '"' || echo "")
SHODAN_TAGS=$(echo "$SHODAN_RESULT"  | grep -oP '"tags":\[.*?\]'  | grep -oP '"[^"]*"' | tr -d '"' || echo "")

if [[ -z "$SHODAN_PORTS" ]]; then
  echo -e "  ${YELLOW}⚠  No data found in Shodan for this IP.${NC}"
  echo -e "  This could mean the host is NOT indexed (not internet-exposed) or was recently added."
else
  echo -e "  ${RED}${BOLD}⚠  Host IS indexed by Shodan (internet-exposed)${NC}"
  echo -e "  Exposed ports  : ${BOLD}$(echo $SHODAN_PORTS | tr '\n' ' ')${NC}"
  [[ -n "$SHODAN_VULNS" ]] && echo -e "  Known CVEs     : ${RED}${BOLD}$SHODAN_VULNS${NC}" || echo -e "  Known CVEs     : ${GREEN}None found${NC}"
  [[ -n "$SHODAN_TAGS" ]]  && echo -e "  Tags           : $SHODAN_TAGS"
fi

echo ""

# ---------- Step 4: Summary verdict ------------------------------------------
echo -e "${BOLD}[4/4] Summary${NC}"
echo -e "─────────────────────────────────────────────"

if [[ -n "$SHODAN_PORTS" ]]; then
  echo -e "  ${RED}${BOLD}VERDICT: HOST IS EXPOSED TO THE INTERNET${NC}"
  echo -e "  Shodan has indexed this IP — it is visible from the public internet."
else
  if [[ ${#OPEN_PORTS[@]} -gt 0 ]]; then
    echo -e "  ${YELLOW}${BOLD}VERDICT: PORTS REACHABLE (not in Shodan yet)${NC}"
    echo -e "  Open ports found but no Shodan record. May be newly exposed or behind a CDN."
  else
    echo -e "  ${GREEN}${BOLD}VERDICT: HOST APPEARS NOT EXPOSED${NC}"
    echo -e "  No open ports detected and no Shodan record found."
  fi
fi

echo ""
echo -e "  Open ports (this scan) : ${#OPEN_PORTS[@]} — ${OPEN_PORTS[*]:-none}"
echo -e "  Closed/filtered        : ${#CLOSED_PORTS[@]} — ${CLOSED_PORTS[*]:-none}"
echo ""
echo -e "─────────────────────────────────────────────"
echo -e "  ${BOLD}Note:${NC} For full internet-wide verification, run from an external"
echo -e "  host outside your network (e.g., a VPS or cloud instance)."
echo ""
