# =============================================================================
# Check-Exposure.ps1 — Internet Exposure Checker (Windows)
# =============================================================================
# Usage:
#   On the target machine:   .\Check-Exposure.ps1
#   On a proxy/jump host:    .\Check-Exposure.ps1 -Target "192.168.1.10"
#   Custom ports:            .\Check-Exposure.ps1 -Ports 22,80,443,3389
#
# Requirements: PowerShell 5.1+ (built-in on Windows 10/Server 2016+)
# Run as: Right-click > "Run with PowerShell" or from PS terminal
# =============================================================================

param(
    [string]$Target  = "",
    [int[]] $Ports   = @(22, 80, 443, 3389, 8080, 8443),
    [int]   $Timeout = 2000   # milliseconds per port check
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------- Helpers -----------------------------------------------------------
function Write-Header {
    Write-Host ""
    Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║     Internet Exposure Checker v1.0       ║" -ForegroundColor Cyan
    Write-Host "║     Windows / PowerShell Edition         ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
}

function Test-Port {
    param([string]$Ip, [int]$Port, [int]$TimeoutMs)
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $conn = $tcp.BeginConnect($Ip, $Port, $null, $null)
        $wait = $conn.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
        if ($wait) {
            $tcp.EndConnect($conn)
            $tcp.Close()
            return $true
        }
        $tcp.Close()
        return $false
    } catch {
        return $false
    }
}

function Get-PublicIP {
    $services = @(
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://icanhazip.com"
    )
    foreach ($svc in $services) {
        try {
            $ip = (Invoke-WebRequest -Uri $svc -UseBasicParsing -TimeoutSec 5).Content.Trim()
            if ($ip -match '^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$') { return $ip }
        } catch { continue }
    }
    return $null
}

function Get-ShodanData {
    param([string]$Ip)
    try {
        $url  = "https://internetdb.shodan.io/$Ip"
        $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 8
        return ($resp.Content | ConvertFrom-Json)
    } catch {
        return $null
    }
}

# ---------- Main --------------------------------------------------------------
Write-Header

$mode = if ($Target -eq "") { "local" } else { "proxy" }
Write-Host "  Mode     : $mode" -ForegroundColor White
Write-Host "  Run time : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host ""

# ---------- Step 1: Resolve IP -----------------------------------------------
Write-Host "[1/4] Resolving target..." -ForegroundColor Yellow

if ($mode -eq "local") {
    $publicIp = Get-PublicIP
    if (-not $publicIp) {
        Write-Host "  ✗ Could not retrieve public IP. Check internet connectivity." -ForegroundColor Red
        exit 1
    }
    $Target = $publicIp
    Write-Host "  Local machine's public IP : $publicIp" -ForegroundColor White
} else {
    # Resolve hostname to IP if needed
    if ($Target -notmatch '^\d{1,3}(\.\d{1,3}){3}$') {
        try {
            $resolved = [System.Net.Dns]::GetHostAddresses($Target) |
                        Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                        Select-Object -First 1 -ExpandProperty IPAddressToString
            Write-Host "  Target : $Target → $resolved" -ForegroundColor White
            $Target = $resolved
        } catch {
            Write-Host "  ✗ Could not resolve hostname: $Target" -ForegroundColor Red
            exit 1
        }
    } else {
        Write-Host "  Target IP : $Target" -ForegroundColor White
    }
}

Write-Host ""

# ---------- Step 2: Port scan ------------------------------------------------
Write-Host "[2/4] Checking port reachability from this host..." -ForegroundColor Yellow
Write-Host "  (Tests if ports respond — does NOT confirm internet-wide exposure)"
Write-Host ""

$openPorts   = @()
$closedPorts = @()

foreach ($port in $Ports) {
    $isOpen = Test-Port -Ip $Target -Port $port -TimeoutMs $Timeout
    if ($isOpen) {
        Write-Host "  Port $port  →  OPEN / REACHABLE" -ForegroundColor Green
        $openPorts += $port
    } else {
        Write-Host "  Port $port  →  CLOSED / FILTERED" -ForegroundColor Red
        $closedPorts += $port
    }
}

Write-Host ""

# ---------- Step 3: Shodan lookup --------------------------------------------
Write-Host "[3/4] Querying Shodan InternetDB (no API key required)..." -ForegroundColor Yellow
Write-Host "  Checking known internet-facing exposure for: $Target"
Write-Host ""

$shodan = Get-ShodanData -Ip $Target

if ($null -eq $shodan -or (-not ($shodan.PSObject.Properties.Name -contains 'ports'))) {
    Write-Host "  ⚠  No data found in Shodan for this IP." -ForegroundColor Yellow
    Write-Host "  This could mean the host is NOT indexed (not internet-exposed) or was recently added."
    $shodanExposed = $false
} else {
    Write-Host "  ⚠  Host IS indexed by Shodan (internet-exposed)" -ForegroundColor Red
    Write-Host "  Exposed ports : $($shodan.ports -join ', ')" -ForegroundColor White

    if ($shodan.vulns -and $shodan.vulns.Count -gt 0) {
        Write-Host "  Known CVEs    : $($shodan.vulns -join ', ')" -ForegroundColor Red
    } else {
        Write-Host "  Known CVEs    : None found" -ForegroundColor Green
    }

    if ($shodan.tags -and $shodan.tags.Count -gt 0) {
        Write-Host "  Tags          : $($shodan.tags -join ', ')"
    }
    $shodanExposed = $true
}

Write-Host ""

# ---------- Step 4: Summary --------------------------------------------------
Write-Host "[4/4] Summary" -ForegroundColor Yellow
Write-Host "─────────────────────────────────────────────"

if ($shodanExposed) {
    Write-Host "  VERDICT: HOST IS EXPOSED TO THE INTERNET" -ForegroundColor Red
    Write-Host "  Shodan has indexed this IP — it is visible from the public internet."
} elseif ($openPorts.Count -gt 0) {
    Write-Host "  VERDICT: PORTS REACHABLE (not in Shodan yet)" -ForegroundColor Yellow
    Write-Host "  Open ports found but no Shodan record. May be newly exposed or behind a CDN."
} else {
    Write-Host "  VERDICT: HOST APPEARS NOT EXPOSED" -ForegroundColor Green
    Write-Host "  No open ports detected and no Shodan record found."
}

Write-Host ""
$openStr   = if ($openPorts.Count   -gt 0) { $openPorts   -join ', ' } else { "none" }
$closedStr = if ($closedPorts.Count -gt 0) { $closedPorts -join ', ' } else { "none" }
Write-Host "  Open ports (this scan) : $($openPorts.Count) — $openStr"
Write-Host "  Closed / filtered      : $($closedPorts.Count) — $closedStr"
Write-Host ""
Write-Host "─────────────────────────────────────────────"
Write-Host "  Note: For full internet-wide verification, run from an external"
Write-Host "  host outside your network (e.g., a VPS or cloud instance)."
Write-Host ""
